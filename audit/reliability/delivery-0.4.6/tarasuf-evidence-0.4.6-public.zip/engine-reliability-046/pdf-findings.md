# Arabic PDF capability work — 0.4.6

## Demonstrated defects and changes

1. **Arabic glyph provenance rejected valid sources.** PDF.js 6.1.200 changes glyph
   paint order into logical reading order using Unicode bidi. The previous exact
   string binding rejected valid ReportLab and LibreOffice Arabic PDFs. The new
   verifier uses the exact pinned PDF.js bidi algorithm from Mozilla (vendored
   `pdf-bidi.js`, Apache license alongside) only to verify the relationship.
   Every non-whitespace character must still be reproduced exactly. Amount or
   reference mutations do not pass this binding; financial strings are not
   heuristically reversed.
2. **Arabic numeric runs were changed by PDF.js bidi.** Visible `(٢٥٠٫٧٥)` became
   extracted `)٢٥٠٫٧٥(`; a visibly ISO Arabic date changed component ordering.
   Purely numeric/date/sign text runs now use their exactly bound glyph order.
   The original PDF is retained; extracted text, used text, glyph text, source
   page/row/column and the rule are recorded in `pdfTextTransforms` and the
   optional `PDF Text Provenance` export worksheet. Currency, digits and signs
   are never substituted.
3. **Legitimate page rectangles were treated as unknown clipping.** Full-page
   clips produced by LibreOffice now pass only if the encoded path is one exact
   axis-aligned rectangle and every glyph's conservative box lies within the
   intersection of active rectangle clips. The box is the union of actual font
   ascent/descent bounds and the earlier conservative bounds. Partial, curved,
   composite or otherwise unknown clipping remains blocked. Background
   visibility accounting uses the actual intersection of the fill and clip.
4. **Multi-line Arabic headers were unresolved.** Header bands now require the
   whole compact geometric band and recognize canonical Arabic header labels
   using NFKC for labels only. `رقم` / `الفاتورة` can be joined with original
   fragments retained. Nearby unknown labels are not silently discarded.
5. **Sign fragments introduced fake whitespace.** Adjacent sign/parenthesis
   glyphs may be joined only with a measured gap ≤ 8% of font height. Separate
   digit groups are never merged. RTL word fragments are ordered geometrically
   only when every fragment is Arabic text without numbers. Both transformations
   are recorded in the export provenance sheet.

## Evidence and measurements

- Actual bytes: `tests/fixtures/pdf-arabic-046/*.pdf`; visible input specification,
  handcrafted expected tuples and producer versions in `manifest.json`.
- Independent producers: ReportLab 4.4.9 / uharfbuzz 0.56.1 / embedded DejaVuSans;
  actual LibreOfficeDev 26.8.0.0.alpha0 HTML conversion.
- Before log: `pdf/targeted-before.jsonl`, baseline code in `../baseline`.
  All 10 fixtures stop at the old glyph binding. This is safe rejection but
  **zero completed positive imports**, not a successful reconciliation.
- Final current targeted suite: 13 tests passing, including 7 clear sources,
  24/24 exact date/reference/signed-minor tuples (72 financial fields), 24 required
  one-to-one matches against independent CSV ledgers and 7 OOXML-checked Excel
  exports. The Arabic balance fixture also gives opening 0, closing 88,570 minor
  SAR, currency SAR and period 2026-07-01 through 2026-07-31 after the coordinated
  structural label-only NFKC fix. No source values or references were normalized
  to recognize these labels.
- Existing PDF suite: 91/91 passing; combined final 104/104.
- All 12 pages of 10 fixtures were visually inspected using Poppler PNGs
  (`pdf/visual-0.png`..`visual-2.png`, `mixed-image-page1/2.png`,
  `reportlab-arabic-balances.png`). No missing glyphs, clipping or column overlap.
- `pdf/evaluate-targeted.mjs` can repeat before/after using current source or
  `../baseline`; `pdf/targeted-current.jsonl` retains actual rows and errors.

## Intervention and boundaries

- Automatic: column layout and field mapping for these positive layouts.
- Explicit accountant confirmation: PDF visual review, scope and sign. The six
  original positive fixtures do not contain identities or a complete period.
  Their accounting scope is **human-external**, not claimed as auto-inferred.
  The seventh fixture exposes currency/period/balances, but supplier/entity/account
  and sign still come from explicit human scope input.
- Corrective work still required for a split reference such as `INV-` followed
  by `00123` on a separate line. The fragment stays a visible source error.
- A second account/table and a source with a later image-only page cannot
  masquerade as completely read data. The latter returns no partial source.
- Chromium experiments with variable/TrueType Arabic fonts exposed invalid
  reader glyph metrics or non-semantic ToUnicode for some glyphs. Those experiments
  remain unsupported and were not counted as valid engine failures.
- The initial Amiri shaping probe produced private-use ToUnicode, and an
  unshaped ReportLab probe had disconnected/reversed glyphs. They were discarded
  after visual/text validation before defining the measured fixture set.
- Arbitrary bidi controls, unsupported fonts, images/OCR, mixed reference wraps
  and multi-table/account inference are not newly claimed as supported.

## Reproduce

From repo: `node --experimental-strip-types --test tests/reliability-arabic-pdf-046.test.ts`.
Generate the small fixtures: `node scripts/generate-arabic-pdf-fixtures-046.mjs`.
Generator runtime variables and dependencies are documented in fixture README.
No production version bump, merge or publish was performed by this subtask.

## Final measured targeted table

| Metric | Baseline 0.4.5 | Current development |
|---|---:|---:|
| Source fixtures executed | 10 | 10 |
| Clear native sources completed | 0/7 | 7/7 |
| Clear tuples verified (date, reference, minor amount) | 0/24 | 24/24 |
| Required matches against independent ledger | 0/24 | 24/24 |
| Required clear matches missed | 24 | 0 |
| Known incorrect accepted matches | 0 | 0 |
| Sources blocked at readFile | 10 | 1 (image second page) |
| Sources retained with explicit incomplete-reading errors | 0 | 2 |
| Independently read Excel exports from clear sources | 0/7 | 7/7 |
| Cases not executed | 0 | 0 |

Per-case rows/errors and counts are in `pdf/targeted-summary.json` and the two
JSONL logs. This is a known development suite; new reserved family evaluation is
owned by the main corpus task and is not included in these counts.
