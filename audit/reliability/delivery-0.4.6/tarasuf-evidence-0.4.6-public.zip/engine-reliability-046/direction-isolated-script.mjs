import { chromium } from 'playwright';
import { verifyVisualReader } from './visual-browser-cases.mjs';
import { verifyTemplateLifecycle } from './lifecycle-browser-cases.mjs';
import {
  verifyBrandLanding,
  verifyNarrowLayouts,
  verifyWorkflowBrand,
} from './brand-browser-cases.mjs';
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import ExcelJS from 'exceljs';
import JSZip from 'jszip';
import { syntheticPdf } from '../tests/helpers/pdf-fixture.ts';
import { syntheticStyledPdf } from '../tests/helpers/styled-pdf-fixture.ts';

async function waitForScopeInputs(page) {
  // These paths are missing an essential value, so the app opens this panel in
  // an effect (or it was already opened in the demo). A visibility check followed
  // by a toggle click can race that effect and close the panel. Wait for the
  // observable result instead; missing-value auto-opening remains an assertion.
  await page
    .getByLabel('العملة', { exact: true })
    .waitFor({ state: 'visible' });
  assert.equal(
    await page
      .getByRole('button', { name: 'تعديل نطاق المقارنة', exact: true })
      .getAttribute('aria-expanded'),
    'true',
    'missing essentials must reveal the scope inputs without a toggle race',
  );
}

// Only synthetic XML emitted by ExcelJS is edited here. The production parser
// canonicalizes namespaces using an XML parser, never these fixture regexes.
async function prefixedWorkbook(workbook) {
  const zip = await JSZip.loadAsync(
    await workbook.xlsx.writeBuffer({ useSharedStrings: true }),
  );
  const main = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const relationships =
    'http://schemas.openxmlformats.org/package/2006/relationships';
  for (const [name, entry] of Object.entries(zip.files)) {
    if (entry.dir || (!name.endsWith('.xml') && !name.endsWith('.rels')))
      continue;
    let xml = await entry.async('string');
    const namespace = xml.includes(`xmlns="${main}"`)
      ? main
      : xml.includes(`xmlns="${relationships}"`)
        ? relationships
        : undefined;
    if (!namespace) continue;
    const prefix = namespace === main ? 'x' : 'pkg';
    xml = xml
      .replace(`xmlns="${namespace}"`, `xmlns:${prefix}="${namespace}"`)
      .replace(/<(\/?)([A-Za-z][\w.-]*)(?=[\s/>])/g, `<$1${prefix}:$2`)
      .replace(/xmlns:r=/g, 'xmlns:rel=')
      .replace(/\sr:id=/g, ' rel:id=');
    zip.file(name, xml);
  }
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
}

async function directionWorkbook(ap, formulas = false) {
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet(ap ? 'AP ledger' : 'Supplier statement');
  sheet.addRows([
    ['Supplier', 'Synthetic Direction Vendor'],
    ['Customer', 'Synthetic Direction Buyer'],
    ['Customer Account', 'DIR-TEST'],
    ['Currency', 'SAR'],
    ['Period', '2026-07-01 to 2026-07-31'],
    [
      ap ? 'Posting Date' : 'Date',
      ap ? 'Doc Type' : 'Type',
      ap ? 'Supplier Ref' : 'Reference',
      'Debit (SAR)',
      'Credit (SAR)',
      ap ? 'Running AP Balance' : 'Running Balance',
    ],
    ['2026-07-01', 'Opening Balance', 'B/F', ap ? 0 : 100, ap ? 100 : 0, 100],
    ['2026-07-02', 'Invoice', 'DIR-INV-100', ap ? 0 : 25, ap ? 25 : 0, 125],
    ['2026-07-03', 'Payment', 'DIR-PAY-100', ap ? 10 : 0, ap ? 0 : 10, 115],
    [ap ? 'Closing AP Balance' : 'Closing Balance', '', '', '', '', 115],
  ]);
  for (const column of [4, 5, 6])
    sheet.getColumn(column).numFmt = '#,##0.00;[Red](#,##0.00)';
  if (formulas) {
    sheet.getCell('F7').value = { formula: '100', result: 100 };
    sheet.getCell('F8').value = {
      formula: ap ? 'F7+E8-D8' : 'F7+D8-E8',
      result: 125,
    };
    sheet.getCell('F9').value = {
      formula: ap ? 'F8+E9-D9' : 'F8+D9-E9',
      result: 115,
    };
    sheet.getCell('F10').value = { formula: 'F9', result: 115 };
  }
  return prefixedWorkbook(workbook);
}

const root = path.resolve('dist');
const server = createServer(async (req, res) => {
  try {
    const u = new URL(req.url, 'http://localhost');
    let rel = decodeURIComponent(u.pathname).replace(/^\/mizan-test\//, '/');
    if (rel === '/') rel = '/index.html';
    const file = path.resolve(root, '.' + rel);
    if (!file.startsWith(root + path.sep)) throw new Error('Invalid path');
    const bytes = await readFile(file);
    const mime =
      {
        '.html': 'text/html; charset=utf-8',
        '.js': 'application/javascript',
        '.css': 'text/css',
        '.svg': 'image/svg+xml',
      }[path.extname(file)] ?? 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': mime,
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(bytes);
  } catch {
    res.writeHead(404);
    res.end('not found');
  }
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const origin = `http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({headless:true});
const context=await browser.newContext({viewport:{width:1440,height:1050}});
context.setDefaultTimeout(10000);
try { const formulas=true;
    const directionPhase = formulas ? 'formula balances' : 'fixed balances';
    await context.setOffline(false);
    const directionPage = await context.newPage();
    await directionPage.goto(`${origin}/mizan-test/`);
    await directionPage.waitForFunction(
      () => !document.body.innerText.includes('جارٍ تجهيز أداة المقارنة'),
    );
    await context.setOffline(true);
    for (const [side, label] of [
      'كشف المورد',
      'تقرير الحسابات الدائنة',
    ].entries()) {
      const name = `synthetic-namespaced-${side}-${formulas ? 'formula' : 'fixed'}.xlsx`;
      await directionPage.getByLabel(label, { exact: true }).setInputFiles({
        name,
        mimeType:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        buffer: await directionWorkbook(side === 1, formulas),
      });
      await directionPage
        .locator('.dropzone')
        .filter({ hasText: label })
        .getByText(name, { exact: true })
        .waitFor();
      await directionPage.waitForFunction(
        () => !document.body.innerText.includes('قراءة الملف على جهازك'),
      );
      assert.deepEqual(
        await directionPage.getByRole('alert').allTextContents(),
        [],
      );
    }
    await directionPage
      .getByRole('button', { name: 'تأكيد البيانات', exact: true })
      .click();
    const directionCompare = directionPage.getByRole('button', {
      name: 'تحقق وقارن',
      exact: true,
    });
    assert.equal(
      // BaseUI Selects render clipped aria-hidden transport inputs. The sign
      // choices are asserted separately below; only actual entry fields count.
      await directionPage
        .locator('input:not([type=checkbox]):not([aria-hidden=true]):visible')
        .count(),
      0,
      `${directionPhase}: known metadata and native numeric cells need no typed fields`,
    );
    assert.equal(await directionPage.getByRole('checkbox').count(), 0);
    const directionQuestion = 'أي عمود يزيد المبلغ المستحق للمورد؟';
    if (formulas) {
      assert.equal(
        await directionPage
          .getByRole('combobox', { name: directionQuestion, exact: true })
          .count(),
        2,
        `${directionPhase}: each source must expose its own direction choice`,
      );
      assert.equal(
        await directionCompare.isDisabled(),
        true,
        'formula caches cannot prove either direction',
      );
      for (const [side, label] of [
        'كشف المورد',
        'تقرير الحسابات الدائنة',
      ].entries()) {
        const card = directionPage.locator('section').filter({
          has: directionPage.getByRole('heading', {
            name: label,
            exact: true,
          }),
        });
        const chooser = card.getByRole('combobox', {name:directionQuestion,exact:true});
        await chooser.scrollIntoViewIfNeeded();
        await chooser.click();
        console.log('opened',side,await directionPage.getByRole('option').allTextContents());
        const target = directionPage.getByRole('option',{name:side===0?'المدين يزيد المستحق':'الدائن يزيد المستحق',exact:true});
        console.log('option',await target.count(),await target.boundingBox());
        await target.click();
        console.log('selected',await chooser.innerText());
        if (side === 0)
          assert.equal(
            await directionCompare.isDisabled(),
            true,
            'the AP direction still requires its own answer',
          );
      }
    } else {
      assert.equal(
        await directionPage.getByRole('combobox').count(),
        0,
        `${directionPhase}: every required choice is established by source evidence`,
      );
    }

} catch(e) { console.error(e); for(const p of context.pages()) { console.log(await p.locator('body').innerText()); await p.screenshot({path:'work/qa/debug-direction.png',fullPage:true}); } } finally { await browser.close(); server.close(); }
