# Independent corpus and evaluator audit — 0.4.6

## Versions and scope

- Generator: `tarasuf-independent-2.0.0`, based on the existing 1.0.1 generator. The original 5,000 documents remain known regression data, not a new holdout.
- Evaluator: `tarasuf-evaluator-2.0.0`; workbook verifier: `tarasuf-workbook-verifier-2.0.0`; input evidence: `tarasuf-visible-inputs-1.0.0`; focused extension: `tarasuf-focused-groups-1.0.0`.
- The original evaluator and original result are preserved under `baseline`. Do not reinterpret the old 5,000/5,000 as fully automatic capability.
- The new focused extension reuses the existing event model and writers. It contains 20 development cases and eight reserved combinations. The latter were defined but NOT generated, rendered or evaluated before root's freeze. Existing writers are reused; these are new combinations, not newly invented independent software producers.

## Every engine input and its origin

| Engine input | Origin in evaluator v2 | UI equivalent / classification |
|---|---|---|
| File bytes and name | Actual independently rendered PDF/CSV/XLSX, SHA-256 checked against original bytes | Upload, automatic |
| Source role | Upload slot, supplier or ledger | User chooses upload slot; no oracle semantics |
| PDF cuts | `undefined`; `autoPdfColumns=true` | Automatic layout proposal, no hidden cut coordinates |
| Sheet/header/columns/mode | `selectImportMapping` from read file | Automatic proposal; if mandatory columns absent, writer-visible header/column positions are explicitly simulated manual correction |
| Date/number format | `suggestFormats` proof across visible values | Proven patch only; ambiguous means unresolved and stopped. No generator locale fallback |
| External format declaration | Only separate `externalInputs` object with `value` and nonempty `source` | Human-external, recorded; never silently supplied by default runner |
| Supplier/entity/account/currency/cutoff | Independently recognized text actually printed by writer; proof records source/page/row/raw text | Engine proposal matching visible value is limited confirmation; unsupported title/banner needs manual entry from visible source |
| Decimals | Public currency-to-minor-unit table after visible currency | Automatic currency convention. Fallback2 only allows malformed-file reading; missing currency prevents normalization |
| Date window | Product default2, verified in app/page.tsx | General setting, not case-specific oracle data |
| Sign multiplier | Actually printed sign-convention sentence | Limited confirmation of visible evidence; never source.metadata.multiplier |
| Report type | Printed report title, with production mapping/default retained and visible open-items selected explicitly | Limited report-type confirmation |
| Period coverage | Both visible statements explicitly print a period | Simulated coverage attestation, recorded separately; engine must still verify periods and balances |
| Scope confirmed | Ordinary Reconcile action | Does not alone count as interpretation or manual correction |
| PDF reviewed | Simulated explicit visual-review acknowledgement | Limited confirmation. This is NOT a claim that a human visually inspected all generated PDFs |
| Opening/closing balances | Production reader extracts from original file | No oracle balances supplied to engine |
| Export review | `{checked:false,name:'',notes:''}` | Unapproved workpaper export, not financial sign-off |
| Expected transactions/matches/groups/balances | Independent oracle, only AFTER engine execution | Verification only; never a source of engine facts |

`automaticInputDerivation`, `explicitAttestations`, `needsChosenInterpretation`, and `externalFacts` are separate from the four aggregate intervention levels. Ordinary Upload/Reconcile clicks do not force a manual classification. Scope entry from a visible title that production inference does not recognize still counts as manual, even if the test can read it easily.

The public engine's current grouping primary reference can legitimately be Bank Reference/Receipt No rather than a generic PAY/PV label. The verifier independently requires the explicit visible payment identity, verifies typed reference fields, AND checks the original generic reference remains in Parsed Supplier/Ledger Source. This is a verifier definition correction, not an engine improvement.

## Leakage found and removed

Evaluator v1 injected generator metadata directly into scope, and supplied an unproven number/date convention from generator layout configuration. Example F01 prints KWD `10.000`: two valid decimal conventions mean 10 KWD or 10,000 KWD. The raw file cannot reveal which hidden minor integer the generator intended. Evaluator v2 stops here unless a separately declared external user input resolves it. Fault-injection unit tests explicitly declare a dot convention to reach calculation stages; these tests are labelled human-external.

A preliminary v2 run of the forty anchors produced 22 completed comparisons, 15 unresolved-format stops and three controlled invalid-source stops, with zero financial assertion failures. These are preliminary measurements, not the frozen final run. Safe stops passing safety assertions do NOT count as completed comparisons. `conditionalRequiredMatches` separates potential matches awaiting input interpretation from `resolvedInputRequiredMatches`.

## Classification of all 154 old payment groups

Detailed per-group visible evidence is retained in `old-154-group-classification.json` (154 records). Every old candidate has a generic Reference, Payment wording (a Document Type column in tabular writers, description text in the native PDF writer), same-date amounts and compatible totals. None has an explicit bank/receipt column, payment component ID or external document establishing attribution. All154 remain **Needs Review**. A shared generic payment label plus arithmetic equality cannot prove that several postings are one whole payment. This is a correction to the old permissive oracle, not an improvement attributed to the engine.

Economic lineage is retained separately from observable permission. The generator never prints hidden event IDs. The business tasks remain separate:
- Document lines: explicit invoice/document identity plus shared PO and distinct full component bucket.
- Whole-payment matching: explicit shared Bank Reference or Receipt No, complete distinct components and no competing occurrences.
- Payment-to-invoice allocation: not inferred from amount equality or common generic labels; remains review.

## New mandatory capability and counterexamples

The20 development cases contain eight required1:N/N:1 decisions: explicit bank payments, explicit receipt payments and explicit invoice/PO lines. One synthetic case is exactly6750=2500+2250+2000 SAR; it is not presented as the user's unavailable original document. Twelve counterexamples cover generic references, sums without identity, conflicting identity, repeated components, missing components, competing use of bank identity, currency, sign, amount basis, type, N:M and extra components.

Independent workbook verification now checks exported accepted memberships against the oracle permission set and checks required groups are present. The engine's own case list is only an interface-consistency check. Hidden Match Evidence must partition rows exactly once; original reference values must survive in raw-source sheets. Optional PDF Text Provenance is independently read as OOXML, its row count and every field are checked against the validated import trace. Financial expected values remain independent canonical source facts.

Targeted tests currently29/29 pass (generator16 + prior fault harness7 + new harness6). New tests prove disabling groups fails completion, forcing generic sums produces FALSE_MATCH, hidden metadata mutation cannot alter any engine input, unresolved locale does not receive oracle defaults, and the export verifier rejects unsupported accepted memberships. Real Arabic producer tests are separate, performed by the PDF agent; do not combine their external-scope setup with claims of automatic input derivation.

## Commands

Use Node runtime in PATH. No remote operations.

```sh
node --experimental-strip-types audit/reliability/run.mjs --suite known --split development,validation,final --engine-root BASELINE --output BEFORE_KNOWN
node --experimental-strip-types audit/reliability/run.mjs --suite known --split development,validation,final --output AFTER_KNOWN
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split development-046 --engine-root BASELINE --output BEFORE_FOCUSED
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split development-046 --output AFTER_FOCUSED
node audit/reliability/compare-runs.mjs BEFORE_KNOWN AFTER_KNOWN known-comparison.json
node audit/reliability/compare-runs.mjs BEFORE_FOCUSED AFTER_FOCUSED focused-comparison.json
```

Before opening reserved cases, freeze current engine (both .ts and .js), generator, evaluator, workbook verifier and exact evaluation settings. The freeze command below hashes descriptors only and DOES NOT generate source files:

```sh
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split final-046 --freeze-only --output FREEZE
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split final-046 --frozen --freeze-file FREEZE/freeze.json --save-files --output RESERVED_RESULT
```

The runner refuses a new reserved run without the frozen file. It checks all hashes, seed, suite, export mode, explicit external inputs and selected case IDs. The old `final` split is known data now. Failed cases are automatically retained as source files + oracle for reproduction. Root must run before/after with the SAME strengthened evaluator/configuration; do not compare v1 headline counts against v2 as product gains.

## Attempt A retained; strict completion and reserved batch B

The first frozen reserved run (`H046-*`) produced3/8 passing cases: five required groups were missed because a legitimate Amount-before-Description balance row was misclassified. The failed first attempt and its original freeze are not overwritten or retroactively counted as a successful unknown test. Its generator/evaluator source is additionally preserved in `attempt-A-audit-source`. The engine fix and any rerun of H046 are now regression work on opened cases.

Evaluator2.1.0 separates:
- `resultProduced`: any returned diagnostic result object.
- `completeSourceRead`: both sources were represented with no source errors and no independently detected missing/changed rows or totals.
- `completedComparison`: a complete read plus no unresolved implicit format convention; decision correctness and required completion remain separate metrics.
- `unprovenFormatDefaults`: invalid/unavailable inference left a product default during diagnostic normalization. These values are never described as an engine proof or supplied external confirmation. They require correction and cannot count as completed accounting work.

C03285 baseline reproduction under evaluator2.1.0 retains its four failure codes,13 row errors, and the wrong KWD row. It reports `resultProduced=true`, `completeSourceRead=false`, `completedComparison=false`, `outcome=partial-or-unverified-result`. The defaults dot/ymd have explicit invalid-inference trace. The diagnostic evidence is in `diagnostic-C03285-strict`; no product code was changed by this evaluator correction.

Generator2.1.0 / focused extension1.1.0 define eight NEW descriptors `J046-001` through `J046-008`, split `final-046-b`. Batch B changes financial components, column permutations, native ExcelJS vs manual OOXML/CSV pairings, Arabic/English labels and numeric styles, with positive groups and negative sign/duplicate/basis combinations. These descriptors have not been generated or evaluated before the next root freeze. The first H046 batch is labelled opened regression in future results.

```sh
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split final-046-b --freeze-only --output FREEZE_B
node --experimental-strip-types audit/reliability/run.mjs --suite focused --split final-046-b --frozen --freeze-file FREEZE_B/freeze.json --save-files --output RESERVED_B_RESULT
```

Two new fault tests prove partial source errors and invalid-format defaults cannot increment completed comparisons. Updated targeted harness:8/8, TypeScript passed. Before/after evaluation must be rerun using the SAME evaluator2.1.0; prior evaluator2.0.0 runs remain attempt A, with their earlier metric definition documented.

The final evaluator optionally loads production `assertInputFormats` from the selected engine root and calls it before normalization, matching the new worker entry point. The baseline has no such module and is explicitly marked `legacy-absent`; the current engine records passed/blocked. A controlled guard stop on a valid supported source remains `INPUT_FORMAT_CAPACITY_GAP`, not success by abstention. Invalid fixtures may stop safely but are never completed comparisons. The prior missing-bridge fault test now removes the bridge from a healthy F01 result, because invalid monetary inputs are correctly blocked before comparison. Both fault harnesses pass15/15 after this integration. No J046 source has been generated.
