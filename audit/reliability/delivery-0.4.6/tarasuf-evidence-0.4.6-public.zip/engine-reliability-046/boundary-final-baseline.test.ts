import test from 'node:test';
import assert from 'node:assert/strict';
import { compare, normalizeSource } from '/Users/togomori/Documents/Codex/2026-09-07/l/work/engine-reliability-046/baseline/lib/reconciliation/core.ts';
import { defaultMapping } from '/Users/togomori/Documents/Codex/2026-09-07/l/work/engine-reliability-046/baseline/lib/reconciliation/types.ts';
import type { SourceFile, Scope } from '/Users/togomori/Documents/Codex/2026-09-07/l/work/engine-reliability-046/baseline/lib/reconciliation/types.ts';

test('046 Arabic presentation forms normalize document categories without rewriting source, references or amounts', () => {
  const scope: Scope = { supplier: '', entity: '', account: '', currency: 'SAR', decimals: 2,
    cutoff: '2026-07-31', dateWindow: 2, confirmed: true, coverageConfirmed: false };
  const mapping = { ...defaultMapping(), date: 0, reference: 1, amount: 2 };
  for (const [raw, plain, expected, amount] of [
    ['ﻓﺎﺗﻮﺭﺓ', 'فاتورة', 'Invoice', '100.00'],
    ['ﺩﻓﻌﺔ', 'دفعة', 'Payment', '-40.00'],
    ['ﺇﺷﻌﺎﺭ ﺩﺍﺋﻦ', 'إشعار دائن', 'Credit Note', '-10.00'],
  ] as const) {
    assert.equal(raw.normalize('NFKC'), plain, 'fixture encodes the intended category');
    const source = (type: string): SourceFile => ({ name: 'synthetic-category.csv', sheets: [{
      name: 'Data', formulaRows: [], hiddenRows: [], rows: [
        ['Date', 'Invoice No', 'Amount', 'نوع المستند'], ['2026-07-15', 'DOC-00046', amount, type],
      ],
    }] });
    const a = source(plain), b = source(raw);
    const original = structuredClone(b);
    const left = normalizeSource(a, mapping, scope, 'supplier');
    const right = normalizeSource(b, mapping, scope, 'ledger');
    assert.equal(right.transactions[0].documentType, expected);
    assert.equal(right.transactions[0].originalAmount, amount);
    assert.equal(right.transactions[0].reference, 'DOC-00046');
    assert.deepEqual(right.transactions[0].referenceEvidenceIssues, []);
    assert.equal(compare(left, right, scope).matches.length, 1);
    assert.deepEqual(b, original);
  }
});
